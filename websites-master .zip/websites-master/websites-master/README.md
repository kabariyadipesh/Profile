# websites
There's a collection of some projects created in HTML+CSS+JS
